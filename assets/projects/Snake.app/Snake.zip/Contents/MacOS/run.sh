#!/bin/bash
cd "$(dirname "$0")" || exit
java -jar "$(dirname "$0")/SnakeGame-0.0.1-SNAPSHOT.jar"
